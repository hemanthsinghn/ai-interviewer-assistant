# AI Interview Assistant (Context-Aware)

## Overview
The AI Interview Assistant is a local, context-aware system designed to assist during technical interviews by analyzing on-screen content, spoken questions, and interaction context.
It observes what is visible on the screen, understands the type of content (code, output, or theory), builds structured context, and generates interview-appropriate responses, scores, and feedback.

The project emphasizes explainable, deterministic logic with selective use of AI models.

---

## Key Features
- Screen understanding via screenshots
- OCR-based text extraction
- UI classification (Code / Slides / Output)
- Context-aware interview prompting
- Deterministic scoring (clarity & technical depth)
- Automated feedback and summary
- Command Line Interface (CLI) demo

---

## System Architecture (High-Level)

Screen Capture  
→ OCR (Tesseract)  
→ UI Classification (Rule-based)  
→ Context Builder  
→ Interview Logic  
→ LLM Reasoning (Gemini)  
→ Scoring Engine (Rule-based)  
→ Feedback & Report  
→ CLI Demo UI  

---

## Models & Engines Used
- **LLM:** Google Gemini (reasoning & feedback generation)
- **Speech-to-Text:** Whisper (local / open-source)
- **OCR:** Tesseract OCR
- **Screen Capture:** pyautogui
- **Scoring & Control Logic:** Rule-based (no ML)

---

## Design Principles
- Engine-first, UI-last architecture
- Deterministic control and evaluation
- AI models used only where necessary
- Fully modular and extendable

---

## How to Run (Demo)
1. Create and activate a Python virtual environment
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the main notebook or CLI demo function:
   ```python
   run_interview_demo()
   ```

---

## Limitations
- OCR accuracy depends on screen quality
- Rule-based UI classification may miss edge cases
- CLI is a demo interface (not user-facing UI)
- LLM API key required for full reasoning

---

## Future Scope
- Web or desktop UI
- Vision-language models instead of OCR
- Real-time STT integration
- Adaptive scoring and analytics dashboard

---

## Conclusion
This project demonstrates a complete, end-to-end AI interview assistant with strong emphasis on explainability, modularity, and real-world interview behavior.
